# GUI Maker 2.5.1 sample world data

Copy `world/data/guimaker/` into the matching save directory while the server or
single-player world is stopped. Replace `world` with the value of `level-name`
when your dedicated server uses another save name.

Files:

- `guis.json` — example two-page market GUI
- `dialogs.json` — six managed dialog examples
- `commands.json` — eight gated command presets
- `limits.json` — per-world capacities
- `widget-state.json` — persistent player/world widget values and holder stacks

Back up an existing `<world>/data/guimaker` directory before replacing it.
Legacy `config/guimaker/*.json` files are also copied automatically when a world
does not yet have its own file.
