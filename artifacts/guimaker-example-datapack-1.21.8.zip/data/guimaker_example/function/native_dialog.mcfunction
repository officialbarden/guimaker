dialog show @s guimaker_example:native_info
