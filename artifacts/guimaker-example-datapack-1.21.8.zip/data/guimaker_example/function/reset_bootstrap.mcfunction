# Allows operators to run the create/edit examples again after deleting them.
data remove storage guimaker_example:state installed
schedule function guimaker_example:bootstrap 1t replace
tellraw @s {"text":"GUI Maker example bootstrap reset and scheduled.","color":"yellow"}
