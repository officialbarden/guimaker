# Idempotent post-startup bootstrap. Minecraft function files omit the leading '/'.
execute if data storage guimaker_example:state {installed:1b} run return 0

# GUI CRUD examples.
guimaker create datapack_demo 3 Datapack-created GUI
guimaker page add datapack_demo 1 3 Datapack Second Page
guimaker page rename datapack_demo 1 Datapack-created Second Page
guimaker action set datapack_demo 0 10 close_gui
guimaker action set datapack_demo 0 11 play_sound ui.button.click
guimaker action set datapack_demo 0 12 run_command show_help
guimaker widget set datapack_demo 0 18 toggle player datapack_toggle false
guimaker widget set datapack_demo 0 19 cycle player datapack_cycle one,two,three
guimaker widget set datapack_demo 0 20 counter world datapack_counter 0,10,1,0
guimaker widget set datapack_demo 0 21 item_holder player datapack_holder

# Managed dialog CRUD/input/action examples.
guimaker dialog create datapack_welcome notice Welcome {player}
guimaker dialog edit body datapack_welcome This managed dialog was created by a scheduled datapack function in {world}.
guimaker dialog action add datapack_welcome welcome_message Continue

guimaker dialog create datapack_form form Datapack Form
guimaker dialog edit body datapack_form Enter a name and submit the gated action.
guimaker dialog input add datapack_form name text Name
guimaker dialog action add datapack_form echo_name Submit Name

guimaker dialog create datapack_wizard wizard Datapack Wizard
guimaker dialog wizard step add datapack_wizard Final Step

# Mark only after all setup commands have been issued.
data modify storage guimaker_example:state installed set value 1b
tellraw @a [{"text":"[GUI Maker Example] ","color":"gold","bold":true},{"text":"World bootstrap completed. Created datapack_demo and managed dialogs.","color":"green"}]
