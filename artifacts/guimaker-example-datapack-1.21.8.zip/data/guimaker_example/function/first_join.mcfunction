tellraw @s [{"text":"Welcome, ","color":"yellow"},{"selector":"@s","color":"gold"},{"text":"! The GUI Maker example is installed.","color":"yellow"}]
guimaker dialog open welcome
