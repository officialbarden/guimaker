# Datapack load functions run before GUI Maker's world repositories are ready.
# Schedule the idempotent bootstrap after server startup instead of writing now.
schedule function guimaker_example:bootstrap 2s replace

tellraw @a [{"text":"[GUI Maker Example] ","color":"gold","bold":true},{"text":"Loaded. Bootstrap scheduled; run /function guimaker_example:help","color":"yellow"}]
