guimaker open market 0
