# GUI Maker example datapack

Target: Minecraft Java 1.21.8 (data pack format 81) and GUI Maker 2.5.1.

Install this directory or its ZIP into `<world>/datapacks/`. Copy the sample
`world/data/guimaker/*.json` files into the active save before starting the
server, or run `/guimaker reload` after copying them.

The load hook schedules `guimaker_example:bootstrap` two seconds later because
datapack load functions execute before GUI Maker's world repositories are
ready. The bootstrap is idempotent and demonstrates these mod commands directly:

- `guimaker create`
- `guimaker page add`, `page rename`, and `action set`
- `guimaker dialog create`, `edit body`, `input add`, and `action add`
- `guimaker dialog wizard step add`

Minecraft function files intentionally omit the leading `/` from commands.

Useful functions:

- `/function guimaker_example:help`
- `/function guimaker_example:open_market`
- `/function guimaker_example:open_welcome`
- `/function guimaker_example:open_profile`
- `/function guimaker_example:native_dialog`
- `/function guimaker_example:give_opener`
- `/function guimaker_example:reset_bootstrap`

The first-join advancement opens the managed `welcome` dialog once per player.
The bootstrap creates `datapack_demo`, `datapack_welcome`, `datapack_form`, and
`datapack_wizard` once per world, tracked in `guimaker_example:state` storage.
